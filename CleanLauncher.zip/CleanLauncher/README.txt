Чистый лаунчер для Android TV
1. Открой папку в Android Studio (File > Open), дождись синхронизации Gradle.
2. Build > Build APK(s) -> app/build/outputs/apk/
3. Установи APK на ТВ (флешка / adb install app-debug.apk).
4. Нажми «Домой» на пульте и выбери «Чистый лаунчер» -> «Всегда».
Долгое нажатие OK на иконке — открыть информацию о приложении (удалить/отключить).

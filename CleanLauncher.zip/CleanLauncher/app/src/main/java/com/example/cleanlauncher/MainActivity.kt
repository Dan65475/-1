package com.example.cleanlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView

class MainActivity : Activity() {

    private class AppItem(
        val label: String,
        val pkg: String,
        val intent: Intent,
        val icon: Drawable,
        val installed: Boolean = true
    )

    // Закреплённые вверху приложения: ищем по части названия
    private class Pin(val keys: List<String>, val title: String, val install: Intent)

    private val pins = listOf(
        Pin(
            listOf("smarttube"),
            "Установить SmartTube",
            Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yuliskov/SmartTube"))
        ),
        Pin(
            listOf("кинопоиск", "kinopoisk"),
            "Установить Кинопоиск",
            Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=Кинопоиск&c=apps"))
        )
    )

    private lateinit var grid: GridView
    private var items: List<AppItem> = emptyList()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(this@MainActivity)
                .inflate(R.layout.item_app, parent, false)
            val item = items[position]
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(item.icon)
            v.findViewById<TextView>(R.id.label).text = item.label
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        grid = findViewById(R.id.grid)
        grid.adapter = adapter

        grid.setOnItemClickListener { _, _, position, _ ->
            try {
                startActivity(items[position].intent)
            } catch (_: Exception) {
            }
        }
        // Долгое нажатие OK — информация о приложении (удалить / отключить)
        grid.setOnItemLongClickListener { _, _, position, _ ->
            if (!items[position].installed) return@setOnItemLongClickListener true
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:" + items[position].pkg))
            )
            true
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    // Кнопка «Домой» просто возвращает в начало списка
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (::grid.isInitialized) grid.setSelection(0)
    }

    // Назад на домашнем экране ничего не делает
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun loadApps() {
        Thread {
            val pm = packageManager
            var list = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0
            )
            if (list.isEmpty()) {
                list = pm.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                )
            }
            val result = list
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val pkg = it.activityInfo.packageName
                    val launch = Intent(Intent.ACTION_MAIN)
                        .setClassName(pkg, it.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    AppItem(it.loadLabel(pm).toString(), pkg, launch, it.loadIcon(pm))
                }
                .sortedBy { it.label.lowercase() }

            // Закреплённые — наверх; если не установлены, показываем плитку «Установить…»
            val top = ArrayList<AppItem>()
            val rest = ArrayList(result)
            val placeholderIcon = resources.getDrawable(R.drawable.ic_launcher)
            for (pin in pins) {
                val found = rest.filter { app -> pin.keys.any { app.label.lowercase().contains(it) } }
                if (found.isNotEmpty()) {
                    top.addAll(found)
                    rest.removeAll(found.toSet())
                } else {
                    top.add(AppItem(pin.title, "", pin.install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), placeholderIcon, false))
                }
            }
            // Плитка «Настройки» всегда под рукой
            top.add(
                AppItem(
                    "Настройки", "",
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    resources.getDrawable(R.drawable.ic_settings), false
                )
            )
            val finalList = top + rest
            runOnUiThread {
                items = finalList
                adapter.notifyDataSetChanged()
            }
        }.start()
    }
}
